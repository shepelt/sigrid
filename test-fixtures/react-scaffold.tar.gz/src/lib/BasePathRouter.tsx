/**
 * BasePathRouter - Handles dynamic base path for React Router
 *
 * This component automatically detects the base path from the URL
 * to support both NOBI preview (/apps/:projectId/) and standalone deployment (/).
 *
 * DO NOT MODIFY THIS FILE - It's infrastructure code for routing.
 */

import { BrowserRouter } from "react-router-dom";
import { ReactNode, useMemo } from "react";

interface BasePathRouterProps {
  children: ReactNode;
}

export function BasePathRouter({ children }: BasePathRouterProps) {
  const basename = useMemo(() => {
    // Detect if running under NOBI preview proxy
    const path = window.location.pathname;
    const match = path.match(/^(\/apps\/[^\/]+)/);
    return match ? match[1] : '/';
  }, []);

  return <BrowserRouter basename={basename}>{children}</BrowserRouter>;
}

// Support both named and default imports
export default BasePathRouter;
