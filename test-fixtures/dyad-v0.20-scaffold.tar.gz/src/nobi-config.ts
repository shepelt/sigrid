// ============================================================================
// 🚨 NOBI DEPLOYMENT CODE - DELETE THIS FILE ON EXPORT 🚨
// ============================================================================
// This file configures the app to work with NOBI's preview proxy.
//
// TO EXPORT FOR PRODUCTION:
// Simply delete this file (nobi-config.ts) - that's it!
// No other changes needed - the app will automatically work standalone.
// ============================================================================

/**
 * Detects if the app is running under NOBI's preview proxy.
 * Returns the base path for React Router.
 *
 * NOBI Preview Pattern: /apps/:projectId/*
 */
function getNobiBasename(): string {
  const path = window.location.pathname;
  const match = path.match(/^(\/apps\/[^\/]+)/);
  return match ? match[1] : '/';
}

// Export as global so App.tsx can use it without import
// When this file is deleted, the global won't exist and app uses default behavior
declare global {
  interface Window {
    __NOBI_GET_BASENAME?: () => string;
  }
}

window.__NOBI_GET_BASENAME = getNobiBasename;

export {};
